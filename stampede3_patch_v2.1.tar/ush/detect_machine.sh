#!/bin/bash

# The authoritative copy of this script lives in the ufs-weather-model at:
# https://github.com/ufs-community/ufs-weather-model/blob/develop/tests/detect_machine.sh
# If any local modifications are made or new platform support added,
# please consider opening an issue and a PR to the ufs-weather-model
# so that this copy remains in sync with its authoritative source
#
# Thank you for your contribution

# If the MACHINE_ID variable is set, skip this script.
if [[ -n "${MACHINE_ID:-}" ]]; then
   echo "We are on " $MACHINE_ID 
   return
fi

# First detect w/ hostname
case $(hostname -f) in

  adecflow0[12].acorn.wcoss2.ncep.noaa.gov)  MACHINE_ID=acorn ;; ### acorn
  alogin0[12].acorn.wcoss2.ncep.noaa.gov)    MACHINE_ID=acorn ;; ### acorn
  clogin0[1-9].cactus.wcoss2.ncep.noaa.gov)  MACHINE_ID=wcoss2 ;; ### cactus01-9
  clogin10.cactus.wcoss2.ncep.noaa.gov)      MACHINE_ID=wcoss2 ;; ### cactus10
  dlogin0[1-9].dogwood.wcoss2.ncep.noaa.gov) MACHINE_ID=wcoss2 ;; ### dogwood01-9
  dlogin10.dogwood.wcoss2.ncep.noaa.gov)     MACHINE_ID=wcoss2 ;; ### dogwood10

  gaea5[1-8])          MACHINE_ID=gaeac5 ;; ### gaea51-58
  gaea5[1-8].ncrc.gov) MACHINE_ID=gaeac5 ;; ### gaea51-58

  gaea6[1-8])          MACHINE_ID=gaeac6 ;; ### gaea61-68
  gaea6[1-8].ncrc.gov) MACHINE_ID=gaeac6 ;; ### gaea61-68

  hfe0[1-9]) MACHINE_ID=hera ;; ### hera01-09
  hfe1[0-2]) MACHINE_ID=hera ;; ### hera10-12
  hecflow01) MACHINE_ID=hera ;; ### heraecflow01

  ufe0[1-9]) MACHINE_ID=ursa ;; ### ursa01-09
  ufe1[0-6]) MACHINE_ID=ursa ;; ### ursa10-16
  uecflow01) MACHINE_ID=ursa ;; ### ursaecflow01

  s4-submit.ssec.wisc.edu) MACHINE_ID=s4 ;; ### s4

  fe[1-8]) MACHINE_ID=jet ;; ### jet01-8
  tfe[12]) MACHINE_ID=jet ;; ### tjet1-2

  Orion-login-[1-4].HPC.MsState.Edu) MACHINE_ID=orion ;; ### orion1-4

  [Hh]ercules-login-[1-4].[Hh][Pp][Cc].[Mm]s[Ss]tate.[Ee]du) MACHINE_ID=hercules ;; ### hercules1-4

  login[1-4].stampede2.tacc.utexas.edu) MACHINE_ID=stampede ;; ### stampede1-4

  login0[1-2].expanse.sdsc.edu) MACHINE_ID=expanse ;; ### expanse1-2

  discover3[1-5].prv.cube) MACHINE_ID=discover ;; ### discover31-35
  *) MACHINE_ID=UNKNOWN ;;  # Unknown platform
esac

if [[ ${MACHINE_ID} == "UNKNOWN" ]]; then
   case ${PW_CSP:-} in
      "aws" | "google" | "azure") MACHINE_ID=noaacloud ;;
      *) PW_CSP="UNKNOWN"
   esac
fi

# Overwrite auto-detect with MACHINE if set
MACHINE_ID=${MACHINE:-${MACHINE_ID}}

# If MACHINE_ID is no longer UNKNNOWN, return it
if [[ "${MACHINE_ID}" != "UNKNOWN" ]]; then
  # TODO: make this read-only when UPP#1308 is addressed.
  declare -x MACHINE_ID  # Should be -rx, but the UPP system needs Gaea C6 to be ID'd as "gaea"
  return
fi
# Try searching based on paths since hostname may not match on compute nodes
if [[ -d /work2/02441/bcash/stampede3 ]]; then
  echo "We are on stampede3"
  MACHINE_ID=stampede3
elif [[ -d /lfs/h3 ]]; then
  # We are on NOAA Cactus or Dogwood
  MACHINE_ID=wcoss2
elif [[ -d /lfs/h1 && ! -d /lfs/h3 ]]; then
  # We are on NOAA TDS Acorn
  MACHINE_ID=acorn
elif [[ -d /mnt/lfs5 ]]; then
  # We are on NOAA Jet
  MACHINE_ID=jet
elif [[ -d /scratch3 ]]; then
  # We are on NOAA Hera or Ursa
  mount=$(findmnt -n -o SOURCE /apps) || true  # /home doesn't exist on the GitHub runners
  if [[ ${mount} =~ "ursa" ]]; then
    MACHINE_ID=ursa
  elif [[ ${mount} =~ "hera" ]]; then
    MACHINE_ID=hera
  else  # Assume we are on the GitHub runners, which mock Hera
    MACHINE_ID=hera
  fi
elif [[ -d /work ]]; then
  # We are on MSU Orion or Hercules
  mount=$(findmnt -n -o SOURCE /home)
  if [[ -n "${mount+0}" && ${mount} =~ "hercules" ]]; then
    MACHINE_ID=hercules
  else
    MACHINE_ID=orion
  fi
elif [[ -d /gpfs/f5 ]]; then
  # We are on GAEAC5.
  MACHINE_ID=gaeac5
elif [[ -d /gpfs/f6 ]]; then
  # We are on GAEAC6.
  MACHINE_ID=gaeac6
elif [[ -d /data/prod ]]; then
  # We are on SSEC's S4
  MACHINE_ID=s4
elif [[ -d /groups/BCASH ]]; then
  # We are on Hopper
  MACHINE_ID=hopper
else
  echo WARNING: UNKNOWN PLATFORM 1>&2
fi
echo "We are on " $MACHINE_ID
# TODO: Make this read-only when UPP#1308 is addressed.
declare -x MACHINE_ID  # Should be -rx, but the UPP system needs Gaea C6 to be ID'd as "gaea"
