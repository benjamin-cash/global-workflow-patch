#!/bin/bash
set -eu

if [[ ${MACHINE_ID} = jet ]] ; then
    # We are on NOAA Jet
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source /apps/lmod/lmod/init/bash
    fi
    module purge

elif [[ ${MACHINE_ID} = hera ]] ; then
    # We are on NOAA Hera
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source /apps/lmod/lmod/init/bash
    fi
    module purge

elif [[ ${MACHINE_ID} = ursa ]] ; then
    # We are on NOAA Ursa
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source /apps/lmod/lmod/init/bash
    fi
    module purge

elif [[ ${MACHINE_ID} = orion ]] ; then
    # We are on Orion
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source /apps/other/lmod/lmod/init/bash
    fi
    module purge

elif [[ ${MACHINE_ID} = hercules ]] ; then
    # We are on Hercules
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source  /apps/other/lmod/lmod/init/bash
    fi
    module purge

elif [[ ${MACHINE_ID} = s4 ]] ; then
    # We are on SSEC Wisconsin S4
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source /usr/share/lmod/lmod/init/bash
    fi
    module purge

elif [[ ${MACHINE_ID} = wcoss2 || ${MACHINE_ID} = acorn ]] ; then
    # We are on NOAA Cactus or Dogwood
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source /usr/share/lmod/lmod/init/bash
    fi
    module purge
    module reset
    
elif [[ ${MACHINE_ID} = derecho ]] ; then
    # We are on NCAR Derecho
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source /glade/u/apps/derecho/23.09/spack/opt/spack/lmod/8.7.24/gcc/7.5.0/c645/lmod/lmod/init/bash
    fi
    module purge
    
elif [[ ${MACHINE_ID} = frontera ]] ; then
    # We are on TACC Frontera
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source /opt/apps/lmod/lmod/init/bash
    fi
    module purge

elif [[ ${MACHINE_ID} = gaeac5 ]] ; then
    # We are on GAEA
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        # We cannot simply load the module command.  The GAEA
        # /etc/profile modifies a number of module-related variables
        # before loading the module command.  Without those variables,
        # the module command fails.  Hence we actually have to source
        # /etc/profile here.
        source /etc/profile
    fi
    module reset
elif [[ ${MACHINE_ID} = gaeac6 ]]; then
    if ( ! eval module help > /dev/null 2>&1 ) ; then
        source /opt/cray/pe/lmod/lmod/init/bash
    fi
    module reset

elif [[ ${MACHINE_ID} = container ]] ; then
    # We are in a container
    source /usr/lmod/lmod/init/bash
    module purge

elif [[ ${MACHINE_ID} = noaacloud ]] ; then
    # We are on NOAA Cloud
    module purge

elif [[ ${MACHINE_ID} == hopper ]]; then
    module purge
    module load singularity
    module use /groups/BCASH/modulefiles/spack-stack-1.9.2/Core
    module use /groups/BCASH/modulefiles/spack-stack-1.9.2/intel-oneapi-mpi/2021.13-argr3sd/gcc/11.4.0

elif [[ ${MACHINE_ID} == stampede3 ]]; then
    module purge
    module load tacc-apptainer
    module use /work2/02441/bcash/stampede3/modulefiles/spack-stack-1.9.2/Core
    module use /work2/02441/bcash/stampede3/modulefiles/spack-stack-1.9.2/intel-oneapi-mpi/2021.13-argr3sd/gcc/11.4.0

else
    	echo WARNING: UNKNOWN PLATFORM 1>&2
fi
